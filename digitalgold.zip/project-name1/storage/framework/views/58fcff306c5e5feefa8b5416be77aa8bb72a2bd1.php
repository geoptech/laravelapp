<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<table class="table">
  <thead class="thead-light">
    <tr>
      <th scope="col">Name</th>
      <th scope="col">amount</th>
      <th scope="col">grams</th>
      <th scope="col">buysell</th>
      <th scope="col">status</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($order->name); ?></th>
      <th scope="row"><?php echo e($order->amount); ?></th>
      <td><?php echo e($order->grams); ?></td>
      <td><?php echo e($order->buysell); ?></td>
      <td><?php echo e($order->status); ?></td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
  </tbody>
</table>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/project-name1/resources/views/Admin/user_info.blade.php ENDPATH**/ ?>