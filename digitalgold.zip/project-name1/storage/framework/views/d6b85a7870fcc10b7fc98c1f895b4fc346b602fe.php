<?php
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2?authorization=oNgOX1Wpyn0rk7GTaChRE6mbHlZcDQUw9q3xdFi5V2JY8AtjLPKy6h8i9Sa2q3kxs0eUIfFmlQHCj5p4&sender_id=TXTIND&message=".urlencode('This is a test message')."&route=v3&numbers=".urlencode('8452825985'),
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "GET",
          CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache"
          ),
        ));
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);
        
        if ($err) {
          echo "cURL Error #:" . $err;
        } else {
          echo $response;
        }
?><?php /**PATH /opt/lampp/htdocs/project-name1/resources/views/testmessage.blade.php ENDPATH**/ ?>